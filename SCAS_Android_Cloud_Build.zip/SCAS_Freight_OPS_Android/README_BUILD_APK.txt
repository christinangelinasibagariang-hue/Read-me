SCAS Freight OPS Android - Android Studio Project
================================================
This ZIP is SOURCE PROJECT, not an already compiled APK.

1. Extract SCAS_Freight_OPS_Android.zip on your Windows PC.
2. Install Android Studio (official Android Developers website).
3. Open the extracted folder SCAS_Freight_OPS_Android (File > Open).
4. Allow Android Studio to download Gradle/Android SDK components and sync project.
5. From Build menu choose Build Bundle(s) / APK(s) > Build APK(s)
   (menu wording varies by Android Studio version).
6. APK path: app/build/outputs/apk/debug/app-debug.apk
7. Transfer APK to Android phone and install. Android may ask to allow
   installing from this source. Only distribute to trusted SCAS staff.

What it does:
- Secure HTTPS wrapper for https://ops.scaslogisticspacking.com/
- Uses existing live SCAS site, login, Supabase and Workers AI.
- No Supabase SQL, migrations, database deletes, or Cloudflare deploy.
- Needs internet connection; site must remain online.
- Android UI is still the existing website UI: responsive mobile styling
  may be needed for comfortable use.

Notes:
- Current app icon is a generic navy placeholder; replace with your approved
  SCAS icon asset before distributing. It is not the official company logo.
- Test login, AI fill, quotation, file uploads, print/export, and navigation
  on actual Android before operational rollout.
- Print and downloads may need native Android implementation; WebView does not
  automatically reproduce all Chrome features.
- Do NOT embed Supabase service_role keys, admin secrets, or AI API keys in APK.
- For public Play Store distribution, configure signing and release compliance.
